How to instal:
--------------
1. Copy the included csgo folder to your Counter-Strike Global Offensive folder, eg "C:\Program Files (x86)\Steam\steamapps\common\Counter-Strike Global Offensive\"
2. Launch the map, by using the console command "map de_bluemall", for an example


--------------
Made by Elias Eskelinen aka "Jonnelafin"